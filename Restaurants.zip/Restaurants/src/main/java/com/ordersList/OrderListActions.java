package com.ordersList;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;

import com.delivery.Deliverydetails;
import com.login.Connect;
import com.login.Users;

public class OrderListActions extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private OrderListEditAdd orderListEditAdd;

	public void init() throws ServletException {
		orderListEditAdd = new OrderListEditAdd();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();
		try {
			switch (action) {
			case "/orderAdd":
				orderListAdd(request, response);
				break;
			case "/orderView":
				orderListView(request, response);
				break;
			case "/viewOrderList":
				viewOrderList(request, response);
				break;
			case "/deliveryorder":
				deliveryOrders(request, response);
				break;
			case "/deliverydetailsOrder":
				adddeliveryOrders(request, response);
				break;
			}
		} catch (Exception ex) {
			throw new ServletException(ex);
		}
	}

	private void viewOrderList(HttpServletRequest request, HttpServletResponse response) {
		Connection con;
		List<JSONObject> list = new ArrayList<>();
		try {

			con = Connect.db();
			if (con != null) {
				System.out.println("connect..");
				String day = request.getParameter("orderday");
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				java.util.Date myDate = format.parse(day);
				long time = myDate.getTime();
				java.sql.Date sqlDate = new java.sql.Date(time);
				try {
					PreparedStatement stmt = con.prepareStatement("SELECT * FROM orders where DATE(orderdate)=?");
					stmt.setDate(1, sqlDate);
					ResultSet rs = stmt.executeQuery();
					System.out.println("json object");
					while (rs.next()) {
						JSONObject obj = new JSONObject();
						obj.put("oid", rs.getInt("orderid"));
						obj.put("uid", rs.getInt("userid"));
						obj.put("address", rs.getString("address"));
						obj.put("zipcode", rs.getString("zipcode"));
						obj.put("phonenumber", rs.getInt("phoneno"));
						obj.put("amount", rs.getInt("amount"));
						obj.put("paymentmode", rs.getString("paymentmode"));
						obj.put("orderstatus", rs.getString("orderstatus"));
						list.add(obj);
					}
					JSONArray jsonArr = new JSONArray(list);
					response.setContentType("application/json");
					PrintWriter out = response.getWriter();
					out.print(jsonArr.toString());
					out.flush();
				} catch (Exception e) {
					System.out.println(e);

				}
			} else {
				System.out.println("conection error");
			}

		} catch (Exception e) {
			System.out.println(e);
		}
	}

	private void adddeliveryOrders(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		System.out.println("add");
		int id = Integer.parseInt(request.getParameter("id"));
		int userId = (int) session.getAttribute("Id");
		String name = (String) session.getAttribute("Name");
		int phone = (int) session.getAttribute("Phone");
		int time = 30;
		Deliverydetails deliverydetails = new Deliverydetails(userId, id, name, phone, time);
		orderListEditAdd.insertdeliveryOrderList(deliverydetails);
		orderListEditAdd.updateOrderList(id);
		response.sendRedirect("delivery.jsp");
	}

	private void deliveryOrders(HttpServletRequest request, HttpServletResponse response) throws Exception {
		List<OrderList> orderList = orderListEditAdd.selectOrderList();
		request.setAttribute("deliveryOrder", orderList);
		RequestDispatcher orderLists = request.getRequestDispatcher("delivery.jsp");
		orderLists.forward(request, response);

	}

	private void orderListView(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		int id = (int) session.getAttribute("Id");
		List<OrderList> orderList = orderListEditAdd.selectAllOrderList(id);
		request.setAttribute("myOrder", orderList);
		RequestDispatcher orderLists = request.getRequestDispatcher("ordersList.jsp");
		orderLists.forward(request, response);

	}

	private void orderListAdd(HttpServletRequest request, HttpServletResponse response) throws Exception {
		HttpSession session = request.getSession();
		int orderId = Users.orderIdnNmber();
		int userId = (int) session.getAttribute("Id");
		String address = (String) session.getAttribute("Address");
		String city = address + (String) session.getAttribute("City");
		String state = city + (String) session.getAttribute("State");
		String pin = (String) session.getAttribute("Pin");
		int phone = (int) session.getAttribute("Phone");
		String amount = request.getParameter("total");
		int total = Integer.parseInt(amount);
		String paymentMode = "COD";
		String orderStatus = "PROCESS";
		OrderList orderList = new OrderList(orderId, userId, state, pin, phone, total, paymentMode, orderStatus);
		orderListEditAdd.insertOrderList(orderList);
		System.out.println(orderList);
		response.sendRedirect("customer.jsp");
	}
}
