package com.ordersList;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.delivery.Deliverydetails;
import com.login.Connect;

public class OrderListEditAdd {

	public void insertOrderList(OrderList orderList) throws Exception {
		// Connection con = db();

		try (Connection con = Connect.db();
				PreparedStatement st = con.prepareStatement(
						"insert into orders (orderId,userId,address,zipCode,phoneNo,amount,paymentMode,orderStatus) values(?,?,?,?,?,?,?,?)");) {
			st.setInt(1, orderList.getOrderId());
			st.setInt(2, orderList.getUserId());
			st.setString(3, orderList.getAddress());
			st.setString(4, orderList.getZipCode());
			st.setInt(5, orderList.getPhoneNo());
			st.setInt(6, orderList.getAmount());
			st.setString(7, orderList.getPaymentMode());
			st.setString(8, orderList.getOrderStatus());
			System.out.println(st);
			st.executeUpdate();
		} catch (Exception e) {
			System.err.println(e);
		}
	}

	public List<OrderList> selectAllOrderList(int id) throws Exception {

		List<OrderList> orderList = new ArrayList<>();
		orderList.clear();
		try (Connection con = Connect.db();
				PreparedStatement st = con.prepareStatement("Select * from orders where userid=?;");) {
			st.setInt(1, id);
			System.out.println(st);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				int orderId = rs.getInt("orderId");
				// int userid = rs.getInt("userId ");
				String address = rs.getString("address");
				String zipCode = rs.getString("zipCode");
				int phoneNo = rs.getInt("phoneNo");
				int amount = rs.getInt("amount");
				String paymentMode = rs.getString("paymentMode");
				String orderStatus = rs.getString("orderStatus");
				Date orderDate = rs.getDate("orderDate");
				orderList.add(new OrderList(orderId, id, address, zipCode, phoneNo, amount, paymentMode, orderStatus,
						orderDate));

				// Gson gson = new Gson();
				// String json = gson.toJson(orderList);
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
		System.out.println("call");
		return orderList;
	}

	public List<OrderList> selectOrderList() throws Exception {
		List<OrderList> orderList = new ArrayList<>();
		orderList.clear();
		try (Connection con = Connect.db(); PreparedStatement st = con.prepareStatement("Select * from orders;");) {
			System.out.println(st);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				int orderId = rs.getInt("orderid");
				int userid = rs.getInt("userid");
				String address = rs.getString("address");
				String zipCode = rs.getString("zipCode");
				int phoneNo = rs.getInt("phoneNo");
				int amount = rs.getInt("amount");
				String paymentMode = rs.getString("paymentMode");
				String orderStatus = rs.getString("orderStatus");
				if (orderStatus.equals("PROCESS")) {
					Date orderDate = rs.getDate("orderDate");
					orderList.add(new OrderList(orderId, userid, address, zipCode, phoneNo, amount, paymentMode,
							orderStatus, orderDate));
				}
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
		System.out.println("call");
		return orderList;
	}

	public void insertdeliveryOrderList(Deliverydetails deliverydetails) throws Exception {

		try (Connection con = Connect.db();
				PreparedStatement st = con.prepareStatement(
						"insert into deliverydetails (id,orderid,deliveryboyname,deliveryboyphoneno,deliverytime) values(?,?,?,?,?)");) {
			st.setInt(1, deliverydetails.getId());
			st.setInt(2, deliverydetails.getOrderId());
			st.setString(3, deliverydetails.getName());
			st.setInt(4, deliverydetails.getPhone());
			st.setInt(5, deliverydetails.getTime());

			System.out.println(st);
			st.executeUpdate();
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public boolean updateOrderList(int id) {
		boolean rowUpdated = false;
		System.out.println("uprun");
		try (Connection con = Connect.db();
				PreparedStatement st = con.prepareStatement("update orders set orderstatus=? where orderid=?");) {
			System.out.println("updated Menu:" + st);
			st.setInt(2, id);
			st.setString(1, "DeliveryOrder");
			System.out.println(st);
			rowUpdated = st.executeUpdate() > 0;

			return rowUpdated;
		} catch (Exception e) {
			System.out.println(e);
		}
		return rowUpdated;
	}

}
