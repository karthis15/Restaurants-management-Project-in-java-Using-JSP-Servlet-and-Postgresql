package com.ordersList;

import java.util.Date;

public class OrderList {
	private int orderId;
	private int userId;
	private String address;
	private String zipCode;
	private int phoneNo;
	private int amount;
	public String paymentMode = "cash on delivery";
	public String orderStatus = "Order Confirmed";
	private Date orderDate;

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public int getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(int phoneNo) {
		this.phoneNo = phoneNo;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getPaymentMode() {
		return paymentMode;
	}

	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	@Override
	public String toString() {
		return "OrderList [orderId=" + orderId + ", userId=" + userId + ", address=" + address + ", zipCode=" + zipCode
				+ ", phoneNo=" + phoneNo + ", amount=" + amount + ", paymentMode=" + paymentMode + ", orderStatus="
				+ orderStatus + ", orderDate=" + orderDate + "]";
	}

	public OrderList(int orderId, int userId, String address, String zipCode, int phoneNo, int amount,
			String paymentMode, String orderStatus, Date orderDate) {
		super();
		this.orderId = orderId;
		this.userId = userId;
		this.address = address;
		this.zipCode = zipCode;
		this.phoneNo = phoneNo;
		this.amount = amount;
		this.paymentMode = paymentMode;
		this.orderStatus = orderStatus;
		this.orderDate = orderDate;
	}

	public OrderList(int orderId, int userId, String address, String pin, int phone, int amount, String paymentMode,
			String orderStatus) {
		super();
		this.orderId = orderId;
		this.userId = userId;
		this.address = address;
		this.zipCode = pin;
		this.phoneNo = phone;
		this.amount = amount;
		this.paymentMode = paymentMode;
		this.orderStatus = orderStatus;
	}

}
