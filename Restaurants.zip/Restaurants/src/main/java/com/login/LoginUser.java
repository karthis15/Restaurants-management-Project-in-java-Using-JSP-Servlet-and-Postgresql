package com.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.userList.UserDetails;

//@WebServlet("/LoginUsers")
public class LoginUser extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<UserDetails> userDetails = new ArrayList<>();
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		Connection con;
		try {
			con = Connect.db();
			String u = request.getParameter("uname");
			String p = request.getParameter("pass");
			PreparedStatement st = con.prepareStatement("select * from customers where email=? and password=?");
			st.setString(1, u);
			st.setString(2, p);
			ResultSet s = st.executeQuery();
			if (s.next()) {
				int id = s.getInt("customer_id");
				String name = s.getString("customer_name");
				String email = s.getString("email");
				String password = s.getString("password");
				int phone = s.getInt("phone_number");
				String address = s.getString("address");
				String city = s.getString("city");
				String state = s.getString("state");
				String pin = s.getString("zip_code");
				String usertype = s.getString("user_type");
				HttpSession session = request.getSession();
				session.setAttribute("Id", id);
				session.setAttribute("Name", name);
				session.setAttribute("Address", address);
				session.setAttribute("City", city);
				session.setAttribute("State", state);
				session.setAttribute("Pin", pin);
				session.setAttribute("Phone", phone);

				if (usertype.equals("admin")) {
					response.sendRedirect("adminpage.jsp");
				} else if (usertype.equals("user")) {
					response.sendRedirect("customer.jsp");
				} else if (usertype.equals("delivery")) {
					response.sendRedirect("delivery.jsp");
				}
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Login successful!');");
				out.println("</script>");
				userDetails.add(new UserDetails(id, name, email, password, phone, address, city, state, pin, usertype));
			} else {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('User or password incorrect');");
				out.println("</script>");
				response.sendRedirect("index.html");
			}

		} catch (Exception e) {
			System.out.println("error " + e);
			response.sendRedirect("index.html");
			e.printStackTrace();
		}
	}

}
