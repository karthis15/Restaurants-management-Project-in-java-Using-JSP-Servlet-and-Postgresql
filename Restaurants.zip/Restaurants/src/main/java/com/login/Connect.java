package com.login;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connect {
	public static Connection db() throws Exception {
		Class.forName("org.postgresql.Driver");
		Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:2020/Restaurant", "postgres", "root");
		return con;
	}
}
