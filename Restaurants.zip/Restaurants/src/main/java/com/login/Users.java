package com.login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;

public class Users extends HttpServlet {
	public static int orderNumber;

	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();
		try {
			switch (action) {
			case "/NewLog":
				adduser(request, response);
				break;
			case "/forgot":
				edituser(request, response);
				break;
			case "/viewusers":
				viewuser(request, response);
				break;
			case "/contact":
				addContact(request, response);
				break;
			}
		} catch (Exception ex) {
			throw new ServletException(ex);
		}
	}

	public static void addContact(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		int id = (int) session.getAttribute("Id");
		String name = (String) session.getAttribute("Name");
		int phone = (int) session.getAttribute("Phone");
		Connection con;
		try {
			System.out.println("con");
			con = Connect.db();
			if (con != null) {
				System.out.println("contact");
				PreparedStatement stmt = con.prepareStatement("insert into contact(userid,email,phoneno) values(?,?,?)",
						Statement.RETURN_GENERATED_KEYS);
				stmt.setInt(1, id);
				stmt.setString(2, name);
				stmt.setInt(3, phone);
				int j = stmt.executeUpdate();
				System.out.println(j + " records inserted" + stmt);
				ResultSet rs = stmt.getGeneratedKeys();
				System.out.println(rs);
				if (rs.next()) {
					orderNumber = rs.getInt("orderId");
					orderIdnNmber();
					// System.out.println(lastInsertedId);
				} else {
					System.out.println("err");
				}
			}

		} catch (Exception e) {
			System.out.println(e);
		}

	}

	public static int orderIdnNmber() {
		return orderNumber;

	}

	private void viewuser(HttpServletRequest request, HttpServletResponse response) {
		Connection con;
		List<JSONObject> list = new ArrayList<>();
		try {

			con = Connect.db();
			if (con != null) {
				System.out.println("connect..");
				String type = request.getParameter("viewtype");
				if (type.equals("forall")) {
					try (PreparedStatement stmt = con.prepareStatement("select * from customers")) {
						ResultSet rs = stmt.executeQuery();
						System.out.println("json object");
						while (rs.next()) {
							JSONObject obj = new JSONObject();
							obj.put("id", rs.getInt("customer_id"));
							obj.put("name", rs.getString("customer_name"));
							list.add(obj);
						}
						JSONArray jsonArr = new JSONArray(list);
						response.setContentType("application/json");
						PrintWriter out = response.getWriter();
						out.print(jsonArr.toString());
						out.flush();

					}
				} else {
					try (PreparedStatement stmt = con.prepareStatement("select * from customers where user_type=?")) {
						stmt.setString(1, type);
						System.out.println("err" + stmt);
						ResultSet rs = stmt.executeQuery();
						while (rs.next()) {
							JSONObject obj = new JSONObject();
							obj.put("id", rs.getInt("customer_id"));
							obj.put("name", rs.getString("customer_name"));
							list.add(obj);
						}
						JSONArray jsonArr = new JSONArray(list);
						response.setContentType("application/json");
						PrintWriter out = response.getWriter();
						out.print(jsonArr.toString());
						out.flush();
					} catch (Exception e) {
						System.out.println(" dis connect..");
					}

				}
			}
		} catch (Exception e) {
			System.out.println("err" + e);
		}

	}

	private void edituser(HttpServletRequest request, HttpServletResponse response) {
		Connection con;
		try {
			con = Connect.db();
			if (con != null) {
				System.out.println("connect..");
				String na = request.getParameter("uname");
				String p1 = request.getParameter("pass1");
				String p2 = request.getParameter("pass2");
				if (p1.equals(p2) && p1 != "") {
					PreparedStatement stmt;
					System.out.println("upp connect..");
					stmt = con.prepareStatement("update customers set password=? where email=?");
					stmt.setString(1, p1);
					stmt.setString(2, na);
					stmt.executeUpdate();
					response.sendRedirect("index.html");
				}
			}
		} catch (Exception e) {

			e.printStackTrace();
		}
	}

	private void adduser(HttpServletRequest request, HttpServletResponse response) {

		Connection con;
		try {
			con = Connect.db();
			if (con != null) {
				System.out.println("connect..");
				String na = request.getParameter("uname");
				String p1 = request.getParameter("pass1");
				String p2 = request.getParameter("pass2");
				String email = request.getParameter("email");
				int phone = Integer.parseInt(request.getParameter("phone"));
				String address = request.getParameter("address");
				String city = request.getParameter("city");
				String state = request.getParameter("state");
				String zip = request.getParameter("zip");
				String usertype = request.getParameter("usertype");
				if (p1.equals(p2) && p1 != "") {
					PreparedStatement stmt;
					try {
						stmt = con.prepareStatement(
								"insert into customers(customer_name,email,password,phone_number,address,city,state,zip_code,user_type) values(?,?,?,?,?,?,?,?,?)");
						stmt.setString(1, na);
						stmt.setString(2, email);
						stmt.setString(3, p1);
						stmt.setInt(4, phone);
						stmt.setString(5, address);
						stmt.setString(6, city);
						stmt.setString(7, state);
						stmt.setString(8, zip);
						stmt.setString(9, usertype);
						int j = stmt.executeUpdate();
						System.out.println(j + " records inserted" + stmt);
						// JOptionPane.showMessageDialog(null, "inserted");
						response.sendRedirect("index.html");
					} catch (Exception e) {
						// PrintWriter out = response.getWriter();
						// out.println("<script> location='Login.jsp';alert('user exiest');</script>");
						// JOptionPane.showMessageDialog(null, "My Goodness, this is so concise");
						response.sendRedirect("Login.jsp");
					}

				} else
					response.sendRedirect("Login.jsp");
			}
		} catch (Exception e) {

			e.printStackTrace();
		}

	}

}
