package com.order;

public class OrderItem {
	private int id;
	public int orderId;
	private int menuId;
	private String itemName;
	private int price;
	public int numberOfItem = 1;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public int getMenuId() {
		return menuId;
	}

	public void setMenuId(int menuId) {
		this.menuId = menuId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public int getNumberOfItem() {
		return numberOfItem;
	}

	public void setNumberOfItem(int numberOfItem) {
		this.numberOfItem = numberOfItem;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "OrderItem [ itemName=" + itemName + ", numberOfItem=" + numberOfItem + "]";
	}

	public OrderItem(int orderId, int menuId, String itemName, int price) {
		super();
		this.orderId = orderId;
		this.menuId = menuId;
		this.itemName = itemName;
		this.price = price;
	}

	public OrderItem(int id, int orderId, int menuId, String itemName, int numberOfItem, int price) {
		super();
		this.id = id;
		this.orderId = orderId;
		this.menuId = menuId;
		this.itemName = itemName;
		this.numberOfItem = numberOfItem;
		this.price = price;
	}

	public OrderItem(int id2, int orderId2, int menuId2, String name, int numberOfItem2) {
		this.id = id2;
		this.orderId = orderId2;
		this.menuId = menuId2;
		this.itemName = name;
		this.numberOfItem = numberOfItem2;

	}

	public OrderItem(int id2, int num) {
		this.id = id2;
		this.numberOfItem = num;
	}

}
