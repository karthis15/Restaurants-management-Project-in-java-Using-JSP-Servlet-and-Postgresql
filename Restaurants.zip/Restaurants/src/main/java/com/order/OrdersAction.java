package com.order;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.login.Users;
import com.menu.MenuItemList;
import com.menu.MenuListAEDR;

public class OrdersAction extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private OrderlistAEDR orderlistAEDR;

	public void init() throws ServletException {
		orderlistAEDR = new OrderlistAEDR();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/neworder":
				showNewOrder(request, response);
				break;
			case "/orderinsert":
				Users.addContact(request, response);
				insertOrder(request, response);
				break;
			case "/orderdelete":
				deleteOrder(request, response);
				break;
			case "/orderedit":
				showEditOrder(request, response);
				break;
			case "/orderupdates":
				updateOrder(request, response);
				break;
			case "/orderlist":
				listOfOrder(request, response);
				break;
			case "/orderlists":
				listOfOrders(request, response);
				break;
			case "/viewoeders":
				viewListOfOrders(request, response);
				break;
			}
		} catch (Exception ex) {
			throw new ServletException(ex);
		}
	}

	private void listOfOrder(HttpServletRequest request, HttpServletResponse response) throws Exception {
		List<OrderItem> listOrder = orderlistAEDR.selectAllOrder();
		request.setAttribute("listOrder", listOrder);
		RequestDispatcher dispatcher = request.getRequestDispatcher("order.jsp");
		dispatcher.forward(request, response);
	}

	private void listOfOrders(HttpServletRequest request, HttpServletResponse response) throws Exception {
		List<OrderItem> listOrder = orderlistAEDR.selectAllOrder();
		request.setAttribute("listOrder", listOrder);
		RequestDispatcher listOrders = request.getRequestDispatcher("orderItems.jsp");
		listOrders.forward(request, response);

	}

	private void viewListOfOrders(HttpServletRequest request, HttpServletResponse response) throws Exception {
		int id = Integer.parseInt(request.getParameter("id"));
		List<OrderItem> listOrder = orderlistAEDR.selectAllOrder(id);
		System.out.println("cone..");
		request.setAttribute("listOrder", listOrder);
		RequestDispatcher listOrders = request.getRequestDispatcher("orderItems.jsp");
		listOrders.forward(request, response);

	}

	private void showNewOrder(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("menu.jsp");
		dispatcher.forward(request, response);
	}

	private void showEditOrder(HttpServletRequest request, HttpServletResponse response) throws Exception {
		try {
			System.out.println("edit error");
			int id = Integer.parseInt(request.getParameter("id"));
			System.out.println("edit error" + id);
			OrderItem existingMenu = orderlistAEDR.selectOrder(id);
			System.out.println(existingMenu.getItemName());
			RequestDispatcher dispatcher = request.getRequestDispatcher("orderItems.jsp");
			System.out.println("sgowessinf error");
			request.setAttribute("menu", existingMenu);
			dispatcher.forward(request, response);
		} catch (Exception e) {
			System.out.println("sfwr error " + e);
		}
	}

	private void insertOrder(HttpServletRequest request, HttpServletResponse response) throws Exception {

		String name[] = request.getParameterValues("selectId");
		int id = Users.orderIdnNmber();
		for (MenuItemList menuList : MenuListAEDR.menuItemList) {
			for (String order : name) {
				int itemId = menuList.getItemId();
				int num = Integer.parseInt(order);
				if (num == itemId) {
					int menuId = itemId;
					System.out.println("conner");
					String itemName = menuList.getItemName();
					int price = menuList.getItemPrice();
					OrderItem newOrder = new OrderItem(id, menuId, itemName, price);
					orderlistAEDR.insertOrder(newOrder);

				} else {
					System.out.println("no t so mow Alj" + num);
				}
			}
		}
		response.sendRedirect("orderlists");
	}

	private void updateOrder(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("up error");
		try {
			String id = request.getParameter("id");
			int ids = Integer.parseInt(id);
			// String name = request.getParameter("name");
			System.out.println("center error");
			int num = Integer.parseInt(request.getParameter("num"));
			// int available_item = Integer.parseInt(request.getParameter("availableItem"));
			OrderItem book = new OrderItem(ids, num);
			System.out.println("name error");
			orderlistAEDR.updateOrder(book);
			response.sendRedirect("orderlists");
		} catch (Exception e) {
			System.out.println("update error" + e);
		}
	}

	private void deleteOrder(HttpServletRequest request, HttpServletResponse response) throws Exception {
		int id = Integer.parseInt(request.getParameter("id"));
		orderlistAEDR.deleteOrder(id);
		response.sendRedirect("orderlists");
	}
}
