package com.order;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.login.Connect;
import com.login.Users;

public class OrderlistAEDR {
//	protected Connection db() throws Exception {
//		// Connection con =null;
//		Class.forName("org.postgresql.Driver");
//		Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:2020/Restaurant", "postgres", "root");
//		return con;
//	}

	public void insertOrder(OrderItem orderItem) throws Exception {
		// Connection con = db();
		Connection con = Connect.db();
		PreparedStatement st = con
				.prepareStatement("insert into orderitems (orderId,menuId,itemName,numberOfItem) values(?,?,?,?)");
		st.setInt(1, orderItem.getOrderId());
		st.setInt(2, orderItem.getMenuId());
		st.setString(3, orderItem.getItemName());
		st.setInt(4, orderItem.numberOfItem);
		System.out.println(st);
		st.executeUpdate();
	}

	public OrderItem selectOrder(int id) throws Exception {
		OrderItem orderItem = null;
		try (Connection con = Connect.db();
				PreparedStatement st = con.prepareStatement("Select * from orderitems where id=?;");) {
			st.setInt(1, id);
			// System.out.println(st);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				int menuId = rs.getInt("menuId");
				int orderId = rs.getInt("orderId");
				String name = rs.getString("itemName");
				int numberOfItem = rs.getInt("numberOfItem");
				orderItem = new OrderItem(id, orderId, menuId, name, numberOfItem);
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
		return orderItem;
	}

	public List<OrderItem> selectAllOrder() throws Exception {

		List<OrderItem> orderItem = new ArrayList<>();
		int orderid = Users.orderIdnNmber();
		try (Connection con = Connect.db();
				PreparedStatement st = con.prepareStatement(
						"select id,orderid,menuid,itemname,numberofitem,item_price from orderitems t1 inner JOIN menuitems t2 ON t1.menuId = t2.item_id where orderid=?;");) {
			st.setInt(1, orderid);
			System.out.println(st);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				int id = rs.getInt("id");
				int orderId = rs.getInt("orderId");
				int menuId = rs.getInt("menuId");
				String name = rs.getString("itemname");
				int numberOfItem = rs.getInt("numberOfItem");
				int price = rs.getInt("item_price");
				price *= numberOfItem;
				System.out.println(price);
				orderItem.add(new OrderItem(id, orderId, menuId, name, numberOfItem, price));
			}

		} catch (SQLException e) {
			System.out.println(e);
		}
		return orderItem;
	}

	public boolean deleteOrder(int id) throws Exception {
		boolean rowDeleted;
		try (Connection con = Connect.db();
				PreparedStatement st = con.prepareStatement("delete from orderitems where id=?");) {
			st.setInt(1, id);
			rowDeleted = st.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateOrder(OrderItem orderItem) throws Exception {
		boolean rowUpdated = false;
		System.out.println("uprun");
		try (Connection con = Connect.db();
				PreparedStatement st = con.prepareStatement("update orderitems set numberofitem=? where id=?");) {
			System.out.println("updated Menu:" + st);
			st.setInt(1, orderItem.getNumberOfItem());
			st.setInt(2, orderItem.getId());
			System.out.println(st);
			rowUpdated = st.executeUpdate() > 0;

			// JSONObject jsonObject = new JSONObject();

			// Add the rowUpdated value to the JSONObject
			// jsonObject.put("rowUpdated", rowUpdated);

			// Convert the JSONObject to a String
			// String jsonResult = jsonObject.toString();

			return rowUpdated;
		} catch (Exception e) {
			System.out.println(e);
		}
		return rowUpdated;
	}

	public List<OrderItem> selectAllOrder(int id) throws Exception {
		List<OrderItem> orderItem = new ArrayList<>();
		try (Connection con = Connect.db();
				PreparedStatement st = con.prepareStatement(
						"select id,orderid,menuid,itemname,numberofitem,item_price from orderitems t1 inner JOIN menuitems t2 ON t1.menuId = t2.item_id where orderid=?;");) {
			st.setInt(1, id);
			System.out.println(st);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				int ids = rs.getInt("id");
				int orderId = rs.getInt("orderId");
				int menuId = rs.getInt("menuId");
				String name = rs.getString("itemname");
				int numberOfItem = rs.getInt("numberOfItem");
				int price = rs.getInt("item_price");
				price *= numberOfItem;
				System.out.println(price);
				orderItem.add(new OrderItem(ids, orderId, menuId, name, numberOfItem, price));
			}

		} catch (SQLException e) {
			System.out.println(e);
		}
		return orderItem;
	}

}
