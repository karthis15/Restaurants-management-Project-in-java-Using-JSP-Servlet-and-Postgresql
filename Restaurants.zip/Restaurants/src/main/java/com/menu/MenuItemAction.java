package com.menu;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MenuItemAction extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static MenuListAEDR menuList;

	public void init() throws ServletException {
		menuList = new MenuListAEDR();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getServletPath();

		try {
			switch (action) {
			case "/new":
				showNewForm(request, response);
				break;
			case "/insert":
				insertMenu(request, response);
				break;
			case "/delete":
				deleteMenu(request, response);
				break;
			case "/edit":
				showEditForm(request, response);
				break;
			case "/update":
				updateMenu(request, response);
				break;
			case "/lists":
				list(request, response);
				break;
			case "/list":
				listMenu(request, response);
				break;
			}
		} catch (Exception ex) {
			throw new ServletException(ex);
		}
	}

	public static void list(HttpServletRequest request, HttpServletResponse response) throws Exception {
		List<MenuItemList> listMenu = menuList.selectAllMenus();
		request.setAttribute("listMenu", listMenu);
		RequestDispatcher listmenus = request.getRequestDispatcher("menuItem.jsp");
		listmenus.forward(request, response);

	}

	private void listMenu(HttpServletRequest request, HttpServletResponse response) throws Exception {
		List<MenuItemList> listMenu = menuList.selectAllMenus();
		request.setAttribute("listMenu", listMenu);
		RequestDispatcher dispatcher = request.getRequestDispatcher("menuItListEdit.jsp");
		dispatcher.forward(request, response);

	}

	private void showNewForm(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("menu.jsp");
		dispatcher.forward(request, response);
	}

	private void showEditForm(HttpServletRequest request, HttpServletResponse response) throws Exception {
		try {
			System.out.println("edit error");
			int id = Integer.parseInt(request.getParameter("id"));
			MenuItemList existingMenu = menuList.selectMenu(id);
			System.out.println(existingMenu.getItemName());
			RequestDispatcher dispatcher = request.getRequestDispatcher("menu.jsp");
			System.out.println("sgowessinf error");
			request.setAttribute("menu", existingMenu);
			dispatcher.forward(request, response);
		} catch (Exception e) {
			System.out.println("sfwr error " + e);
		}
	}

	private void insertMenu(HttpServletRequest request, HttpServletResponse response) throws Exception {

		String name = request.getParameter("name");
		int price = Integer.parseInt(request.getParameter("price"));
		MenuItemList newMenu = new MenuItemList(name, price);
		menuList.insertMenu(newMenu);
		response.sendRedirect("list");
	}

	private void updateMenu(HttpServletRequest request, HttpServletResponse response) {
		System.out.println("up error");
		try {
			int id = Integer.parseInt(request.getParameter("id"));
			String name = request.getParameter("name");
			System.out.println("center error");
			int price = Integer.parseInt(request.getParameter("price"));
			MenuItemList book = new MenuItemList(id, name, price);
			System.out.println("name error");
			menuList.updateMenu(book);
			response.sendRedirect("list");
		} catch (Exception e) {
			System.out.println("update error" + e);
		}
	}

	private void deleteMenu(HttpServletRequest request, HttpServletResponse response) throws Exception {
		int id = Integer.parseInt(request.getParameter("id"));
		menuList.deleteMenu(id);
		response.sendRedirect("list");
	}

}
