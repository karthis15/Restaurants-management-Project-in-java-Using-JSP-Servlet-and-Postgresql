package com.menu;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.login.Connect;

public class MenuListAEDR {
	public static List<MenuItemList> menuItemList = new ArrayList<>();

	public void insertMenu(MenuItemList menuItemList) throws Exception {
		Connection con = Connect.db();
		PreparedStatement st = con.prepareStatement("insert into menuitems(item_name,item_price) values(?,?,?)");
		st.setString(1, menuItemList.getItemName());
		st.setInt(2, menuItemList.getItemPrice());
		System.out.println(st);
		st.executeUpdate();
	}

	public MenuItemList selectMenu(int id) throws Exception {
		MenuItemList menuItemList = null;
		try (Connection con = Connect.db();
				PreparedStatement st = con.prepareStatement("Select * from menuitems where item_id=?;");) {
			st.setInt(1, id);
			// System.out.println(st);
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				String name = rs.getString("item_name");
				int price = rs.getInt("item_price");
				menuItemList = new MenuItemList(id, name, price);
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
		return menuItemList;
	}

	public List<MenuItemList> selectAllMenus() throws Exception {

		try (Connection con = Connect.db(); PreparedStatement st = con.prepareStatement("Select * from menuitems;");) {
			System.out.println(st);
			menuItemList.clear();
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				// System.out.println(rs.getObject(2));
				int id = rs.getInt("item_id");
				String name = rs.getString("item_name");
				int price = rs.getInt("item_price");
				menuItemList.add(new MenuItemList(id, name, price));
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
		return menuItemList;
	}

	public boolean deleteMenu(int id) throws Exception {
		boolean rowDeleted;
		try (Connection con = Connect.db();
				PreparedStatement st = con.prepareStatement("delete from menuitems where item_id=?");) {
			st.setInt(1, id);
			rowDeleted = st.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateMenu(MenuItemList menuItemList) throws Exception {
		boolean rowUpdated = false;
		System.out.println("uprun");
		try (Connection con = Connect.db();
				PreparedStatement st = con
						.prepareStatement("update menuitems set item_name=?,item_price=? where item_id=?");) {
			System.out.println("updated Menu:" + st);
			st.setString(1, menuItemList.getItemName());
			st.setInt(2, menuItemList.getItemPrice());
			st.setInt(4, menuItemList.getItemId());
			System.out.println(st);
			rowUpdated = st.executeUpdate() > 0;
			return rowUpdated;
		} catch (Exception e) {
			System.out.println(e);
		}
		return rowUpdated;
	}
}
