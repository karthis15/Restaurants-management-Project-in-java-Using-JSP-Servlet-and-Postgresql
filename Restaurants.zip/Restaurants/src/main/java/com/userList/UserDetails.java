package com.userList;

public class UserDetails {
	private int id;
	private String customer_name;
	private String email;
	private String password;
	private int phone_number;
	private String address;
	private String city;
	private String state;
	private String zip_code;
	private String user_type;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCustomer_name() {
		return customer_name;
	}

	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public int getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(int phone_number) {
		this.phone_number = phone_number;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip_code() {
		return zip_code;
	}

	public void setZip_code(String zip_code) {
		this.zip_code = zip_code;
	}

	public String getUser_type() {
		return user_type;
	}

	public void setUser_type(String user_type) {
		this.user_type = user_type;
	}

	@Override
	public String toString() {
		return "UserDetails [id=" + id + ", customer_name=" + customer_name + ", email=" + email + ", password="
				+ password + ", phone_number=" + phone_number + ", address=" + address + ", city=" + city + ", state="
				+ state + ", zip_code=" + zip_code + ", user_type=" + user_type + "]";
	}

	public UserDetails(int id, String customer_name, String email, String password, int phone_number, String address,
			String city, String state, String zip_code, String user_type) {
		super();
		this.id = id;
		this.customer_name = customer_name;
		this.email = email;
		this.password = password;
		this.phone_number = phone_number;
		this.address = address;
		this.city = city;
		this.state = state;
		this.zip_code = zip_code;
		this.user_type = user_type;
	}

}
