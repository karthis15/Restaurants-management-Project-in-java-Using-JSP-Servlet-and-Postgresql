package com.userList;

public class Address {
	private String address;
	private String city;
	private String state;
	private String zip_code;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip_code() {
		return zip_code;
	}

	public void setZip_code(String zip_code) {
		this.zip_code = zip_code;
	}

	@Override
	public String toString() {
		return "Address [address=" + address + ", city=" + city + ", state=" + state + ", zip_code=" + zip_code + "]";
	}

	public Address(String address, String city, String state, String zip_code) {
		super();
		this.address = address;
		this.city = city;
		this.state = state;
		this.zip_code = zip_code;
	}

}
