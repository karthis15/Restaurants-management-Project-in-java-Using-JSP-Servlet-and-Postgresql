package com.delivery;

import java.util.Date;

public class Deliverydetails {
	private int id;
	private int orderId;
	private String name;
	private int phone;
	private int time;
	private Date date;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getPhone() {
		return phone;
	}

	public void setPhone(int phone) {
		this.phone = phone;
	}

	public int getTime() {
		return time;
	}

	public void setTime(int time) {
		this.time = time;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Deliverydetails [id=" + id + ", orderId=" + orderId + ", name=" + name + ", phone=" + phone + ", time="
				+ time + ", date=" + date + "]";
	}

	public Deliverydetails(int id, int orderId, String name, int phone, int time) {
		super();
		this.id = id;
		this.orderId = orderId;
		this.name = name;
		this.phone = phone;
		this.time = time;
	}

}
